import type { Metadata } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { SITE } from "@/lib/utils";
import WhatsappFloat from "@/components/whatsapp-float";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  display: "swap",
  weight: ["500", "600", "700"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
  weight: ["400", "500"],
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: {
    default: "GD Tech — Assistência Técnica de Smartphones no Rio de Janeiro",
    template: "%s | GD Tech",
  },
  description:
    "Troca de tela, bateria, conector de carga e diagnóstico especializado para smartphones. Orçamento sem compromisso pelo WhatsApp, peças com garantia e serviço no mesmo dia.",
  keywords: [
    "assistência técnica de celular",
    "conserto de smartphone",
    "troca de tela",
    "troca de bateria",
    "conserto de celular Rio de Janeiro",
    "GD Tech",
  ],
  authors: [{ name: "GD Tech" }],
  robots: { index: true, follow: true },
  alternates: { canonical: SITE.url },
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: SITE.url,
    siteName: "GD Tech",
    title: "GD Tech — Assistência Técnica de Smartphones",
    description:
      "Diagnóstico preciso, peças com garantia e reparo no mesmo dia. Fale agora pelo WhatsApp.",
    images: [{ url: "/og-image.jpg", width: 1200, height: 630, alt: "GD Tech" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "GD Tech — Assistência Técnica de Smartphones",
    description:
      "Diagnóstico preciso, peças com garantia e reparo no mesmo dia. Fale agora pelo WhatsApp.",
    images: ["/og-image.jpg"],
  },
  icons: { icon: "/favicon.ico" },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "ElectronicsStore",
  name: "GD Tech",
  description:
    "Assistência técnica especializada em smartphones: troca de tela, bateria, conector de carga, câmeras, software e diagnóstico.",
  telephone: `+55${SITE.phone}`,
  url: SITE.url,
  address: {
    "@type": "PostalAddress",
    addressLocality: SITE.city,
    addressRegion: SITE.region,
    addressCountry: "BR",
  },
  priceRange: "$$",
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      opens: "09:00",
      closes: "18:00",
    },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable}`}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body>
        {children}
        <WhatsappFloat />
      </body>
    </html>
  );
}
