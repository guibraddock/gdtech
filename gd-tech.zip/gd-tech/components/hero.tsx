"use client";

import { motion } from "framer-motion";
import { ShieldCheck, Clock3, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { whatsappLink } from "@/lib/utils";

export default function Hero() {
  return (
    <section
      id="top"
      className="relative overflow-hidden bg-graphite-950 pb-20 pt-32 sm:pt-40"
    >
      <div className="bg-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_40%,transparent_100%)]" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-[520px] w-[720px] -translate-x-1/2 rounded-full bg-solder/10 blur-[120px]" />

      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 px-5 sm:px-8 lg:grid-cols-2">
        {/* Copy */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
        >
          <span className="section-label mb-6 inline-flex items-center gap-2 rounded-full border border-solder/25 bg-solder/5 px-3 py-1.5">
            // diagnóstico_gratuito.exe
          </span>

          <h1 className="font-display text-4xl font-bold leading-[1.08] tracking-tight text-bone-50 sm:text-5xl lg:text-[3.4rem]">
            Seu smartphone quebrou.
            <br />
            <span className="text-gradient">Nós já sabemos o porquê.</span>
          </h1>

          <p className="mt-6 max-w-lg text-lg leading-relaxed text-bone-400">
            Diagnóstico técnico preciso, peças com garantia real e reparo no
            mesmo dia. Sem enrolação, sem letras miúdas — só o seu aparelho
            funcionando de novo.
          </p>

          <div className="mt-9 flex flex-col gap-4 sm:flex-row">
            <a
              href={whatsappLink("Olá! Meu aparelho apresentou um problema e quero um diagnóstico.")}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="lg" className="w-full sm:w-auto">
                Diagnosticar meu aparelho agora
              </Button>
            </a>
            <a href="#servicos">
              <Button size="lg" variant="outline" className="w-full sm:w-auto">
                Ver serviços
              </Button>
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 border-t border-white/5 pt-6 text-sm text-bone-400">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-solder" />
              Garantia em peças e serviço
            </div>
            <div className="flex items-center gap-2">
              <Clock3 className="h-4 w-4 text-solder" />
              Conserto no mesmo dia
            </div>
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-solder" />
              4.9/5 de avaliação
            </div>
          </div>
        </motion.div>

        {/* Signature visual: diagnostic scan mockup */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.15 }}
          className="relative mx-auto w-full max-w-sm"
        >
          <div className="relative mx-auto aspect-[9/18.5] w-64 overflow-hidden rounded-[2.5rem] border-4 border-graphite-700 bg-graphite-900 shadow-card sm:w-72">
            {/* screen content */}
            <div className="absolute inset-0 bg-gradient-to-b from-graphite-800 to-graphite-950 p-4 font-mono text-[10px] text-diagnostic-light">
              <p className="text-solder">GD_TECH // DIAG v2.1</p>
              <div className="mt-3 space-y-1.5 opacity-80">
                <p>tela ................ OK</p>
                <p>bateria .............. 94%</p>
                <p>câmeras .............. OK</p>
                <p>conector de carga .... verificando</p>
                <p>alto-falante ......... OK</p>
                <p>microfone ............ OK</p>
              </div>
              <div className="mt-6 h-24 rounded-lg border border-white/10 bg-white/[0.02]" />
            </div>

            {/* scanline */}
            <div className="pointer-events-none absolute inset-x-0 top-0 h-16 animate-scanline bg-gradient-to-b from-transparent via-solder/40 to-transparent" />

            {/* notch */}
            <div className="absolute left-1/2 top-2 h-4 w-20 -translate-x-1/2 rounded-full bg-graphite-950" />
          </div>

          <div className="absolute -bottom-4 left-1/2 w-52 -translate-x-1/2 rounded-2xl border border-white/5 bg-graphite-900/90 px-4 py-3 text-center shadow-card backdrop-blur">
            <p className="font-mono text-[10px] uppercase tracking-widest text-diagnostic-light">
              status do diagnóstico
            </p>
            <p className="font-display text-sm font-semibold text-solder">
              Aparelho identificado ✓
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
