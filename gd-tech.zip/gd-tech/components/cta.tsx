"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { whatsappLink, SITE } from "@/lib/utils";

export default function CTA() {
  return (
    <section className="relative overflow-hidden bg-graphite-950 py-24 sm:py-32">
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[720px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-solder/10 blur-[130px]" />
      <div className="relative mx-auto max-w-3xl px-5 text-center sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
            Seu aparelho não precisa esperar mais um dia
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-bone-400">
            Envie uma mensagem agora e receba o diagnóstico gratuito. Sem compromisso, sem enrolação.
          </p>

          <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a
              href={whatsappLink("Olá! Quero fazer o diagnóstico gratuito do meu aparelho agora.")}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="lg">Quero meu diagnóstico gratuito</Button>
            </a>
            <span className="font-mono text-sm text-bone-400">{SITE.phoneDisplay}</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
