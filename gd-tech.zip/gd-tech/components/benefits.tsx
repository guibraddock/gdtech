"use client";

import { motion } from "framer-motion";
import { Gauge, ShieldCheck, Eye, Award } from "lucide-react";

const items = [
  {
    icon: Gauge,
    title: "Velocidade real",
    desc: "A maioria dos reparos sai no mesmo dia — sem seu aparelho passar semanas na bancada.",
  },
  {
    icon: Eye,
    title: "Transparência técnica",
    desc: "Você vê o diagnóstico antes de aprovar qualquer serviço. Sem surpresa na hora de pagar.",
  },
  {
    icon: ShieldCheck,
    title: "Peças com procedência",
    desc: "Trabalhamos apenas com peças testadas, com garantia formal em cada troca.",
  },
  {
    icon: Award,
    title: "Especialistas, não generalistas",
    desc: "Técnicos focados em smartphones — não é um conserto genérico de eletrônicos.",
  },
];

export default function Benefits() {
  return (
    <section className="relative overflow-hidden bg-graphite-900 py-24 sm:py-32">
      <div className="bg-grid pointer-events-none absolute inset-0 opacity-40 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_50%,#000_30%,transparent_100%)]" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-label">// 03_por_que_a_gd_tech</span>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            O que muda quando o reparo é feito certo
          </h2>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((it, i) => (
            <motion.div
              key={it.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="text-center sm:text-left"
            >
              <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl border border-solder/25 bg-solder/5 text-solder sm:mx-0">
                <it.icon className="h-5 w-5" strokeWidth={2} />
              </span>
              <h3 className="mt-4 font-display text-lg font-semibold">{it.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-bone-400">{it.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
