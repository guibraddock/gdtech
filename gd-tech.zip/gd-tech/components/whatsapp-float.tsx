"use client";

import { MessageCircle } from "lucide-react";
import { whatsappLink } from "@/lib/utils";

export default function WhatsappFloat() {
  return (
    <a
      href={whatsappLink("Olá! Vim pelo site e quero fazer um orçamento para o meu aparelho.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar com a GD Tech no WhatsApp"
      className="group fixed bottom-6 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-solder text-graphite-950 shadow-glow transition-all duration-300 hover:w-[13.5rem] hover:justify-start hover:px-4 sm:bottom-8 sm:right-8"
    >
      <MessageCircle className="h-6 w-6 shrink-0" strokeWidth={2.25} />
      <span className="ml-0 w-0 overflow-hidden whitespace-nowrap text-sm font-display font-semibold opacity-0 transition-all duration-300 group-hover:ml-2 group-hover:w-auto group-hover:opacity-100">
        Falar no WhatsApp
      </span>
      <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-solder/40 [animation-duration:2.4s]" />
    </a>
  );
}
