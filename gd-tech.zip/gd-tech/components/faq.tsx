import AccordionItem from "@/components/ui/accordion-item";

const faqs = [
  {
    q: "Quanto tempo leva o conserto?",
    a: "A maioria dos serviços — troca de tela, bateria e conector de carga — é feita no mesmo dia. Casos de software ou peças específicas podem levar até 48h, sempre informado no diagnóstico.",
  },
  {
    q: "O orçamento tem custo?",
    a: "Não. O diagnóstico e o orçamento são gratuitos e sem compromisso. Você só paga se decidir seguir com o reparo.",
  },
  {
    q: "As peças têm garantia?",
    a: "Sim. Toda peça trocada sai com garantia formal, cobrindo defeito de fabricação e problemas relacionados à instalação.",
  },
  {
    q: "Vocês desbloqueiam qualquer aparelho?",
    a: "Realizamos desbloqueios legais apenas mediante comprovação de propriedade do aparelho, seguindo a legislação vigente.",
  },
  {
    q: "Meus dados ficam seguros durante o reparo?",
    a: "Sim. Trabalhamos apenas nos componentes necessários para o serviço solicitado e não acessamos dados pessoais do aparelho.",
  },
];

export default function FAQ() {
  return (
    <section id="faq" className="bg-graphite-900 py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-5 sm:px-8">
        <div className="text-center">
          <span className="section-label">// 07_perguntas_frequentes</span>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Antes de chamar no WhatsApp
          </h2>
        </div>

        <div className="mt-12">
          {faqs.map((f) => (
            <AccordionItem key={f.q} question={f.q} answer={f.a} />
          ))}
        </div>
      </div>
    </section>
  );
}
