"use client";

import { motion } from "framer-motion";
import {
  Smartphone,
  BatteryCharging,
  Plug,
  Volume2,
  Mic,
  Camera,
  Cpu,
  RefreshCw,
  Search,
  Unlock,
} from "lucide-react";
import { whatsappLink } from "@/lib/utils";

const services = [
  { icon: Smartphone, title: "Troca de tela", desc: "Peças originais ou premium, com teste de toque e cor antes da entrega." },
  { icon: BatteryCharging, title: "Troca de bateria", desc: "Diagnóstico de saúde da bateria e substituição com garantia." },
  { icon: Plug, title: "Conector de carga", desc: "Limpeza, reparo ou troca — resolve carregamento instável ou inexistente." },
  { icon: Volume2, title: "Alto-falante", desc: "Áudio baixo, chiado ou mudo: identificamos e resolvemos a causa." },
  { icon: Mic, title: "Microfone", desc: "Reparo para ligações e gravações sem falhas de captação." },
  { icon: Camera, title: "Câmeras", desc: "Foco, mancha, tela preta ou câmera quebrada — frontal e traseira." },
  { icon: Cpu, title: "Software", desc: "Travamentos, lentidão, erros de sistema e otimização geral." },
  { icon: RefreshCw, title: "Atualizações", desc: "Sistema sempre atualizado, estável e seguro." },
  { icon: Search, title: "Diagnóstico", desc: "Avaliação técnica completa antes de qualquer decisão sua." },
  { icon: Unlock, title: "Desbloqueios legais", desc: "Mediante comprovação de propriedade do aparelho." },
];

export default function Services() {
  return (
    <section id="servicos" className="relative bg-graphite-950 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-label">// 02_serviços</span>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Um serviço técnico para cada componente do seu aparelho
          </h2>
          <p className="mt-4 text-bone-400">
            Se o problema está na tela, na bateria ou no software, tratamos com o mesmo padrão de precisão.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {services.map((s, i) => (
            <motion.a
              key={s.title}
              href={whatsappLink(`Olá! Quero saber mais sobre o serviço de ${s.title.toLowerCase()}.`)}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: (i % 5) * 0.06 }}
              className="group relative flex flex-col gap-3 rounded-2xl border border-white/5 bg-graphite-900 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-solder/30 hover:shadow-glow lg:[&:nth-child(n+6)]:col-span-1"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-solder/10 text-solder transition-colors group-hover:bg-solder/20">
                <s.icon className="h-5 w-5" strokeWidth={2} />
              </span>
              <h3 className="font-display text-base font-semibold">{s.title}</h3>
              <p className="text-sm leading-relaxed text-bone-400">{s.desc}</p>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
