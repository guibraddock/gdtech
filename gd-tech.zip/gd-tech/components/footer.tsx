import { Wrench, MapPin, Phone, Clock } from "lucide-react";
import { SITE, whatsappLink } from "@/lib/utils";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-graphite-950 pt-16">
      <div className="mx-auto max-w-7xl px-5 pb-10 sm:px-8">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <a href="#top" className="flex items-center gap-2 font-display text-lg font-bold">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-solder/15 text-solder">
                <Wrench className="h-4 w-4" strokeWidth={2.5} />
              </span>
              GD<span className="text-gradient">Tech</span>
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-bone-400">
              Assistência técnica especializada em smartphones, com diagnóstico
              preciso e peças com garantia.
            </p>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-solder">Serviços</h4>
            <ul className="mt-4 space-y-2 text-sm text-bone-400">
              <li>Troca de tela</li>
              <li>Troca de bateria</li>
              <li>Conector de carga</li>
              <li>Diagnóstico e software</li>
              <li>Desbloqueios legais</li>
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-solder">Contato</h4>
            <ul className="mt-4 space-y-3 text-sm text-bone-400">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-solder" />
                <a
                  href={whatsappLink("Olá! Vim pelo site da GD Tech.")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-bone-50"
                >
                  {SITE.phoneDisplay}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-solder" />
                {SITE.city} — {SITE.region}
              </li>
              <li className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-solder" />
                Seg. a sáb., 9h às 18h
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-solder">Navegação</h4>
            <ul className="mt-4 space-y-2 text-sm text-bone-400">
              <li><a href="#servicos" className="hover:text-bone-50">Serviços</a></li>
              <li><a href="#como-funciona" className="hover:text-bone-50">Como Funciona</a></li>
              <li><a href="#garantia" className="hover:text-bone-50">Garantia</a></li>
              <li><a href="#faq" className="hover:text-bone-50">FAQ</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-6 text-xs text-bone-400 sm:flex-row">
          <p>© {new Date().getFullYear()} GD Tech. Todos os direitos reservados.</p>
          <p className="font-mono">Desbloqueios realizados apenas mediante comprovação de propriedade.</p>
        </div>
      </div>
    </footer>
  );
}
