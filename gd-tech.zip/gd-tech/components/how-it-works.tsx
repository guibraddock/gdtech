"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { whatsappLink } from "@/lib/utils";

const steps = [
  {
    n: "01",
    title: "Você chama no WhatsApp",
    desc: "Descreve o problema e, se puder, envia fotos. Em minutos você já tem uma estimativa.",
  },
  {
    n: "02",
    title: "Diagnóstico na bancada",
    desc: "Avaliamos o aparelho tecnicamente e confirmamos o valor exato antes de qualquer reparo.",
  },
  {
    n: "03",
    title: "Reparo e teste final",
    desc: "Executamos o serviço, testamos cada função afetada e só então devolvemos o aparelho.",
  },
];

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="bg-graphite-950 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-label">// 04_fluxo_de_atendimento</span>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Do primeiro contato ao aparelho na sua mão
          </h2>
        </div>

        <div className="relative mt-16 grid grid-cols-1 gap-10 md:grid-cols-3">
          <div className="pointer-events-none absolute left-0 right-0 top-8 hidden h-px bg-gradient-to-r from-transparent via-white/10 to-transparent md:block" />
          {steps.map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: i * 0.12 }}
              className="relative"
            >
              <span className="font-mono text-4xl font-medium text-solder/25">{s.n}</span>
              <h3 className="mt-3 font-display text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-bone-400">{s.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href={whatsappLink("Olá! Quero iniciar meu atendimento com a GD Tech.")}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg">Iniciar meu atendimento</Button>
          </a>
        </div>
      </div>
    </section>
  );
}
