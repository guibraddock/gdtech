"use client";

import { motion } from "framer-motion";
import { ShieldCheck, CheckCircle2 } from "lucide-react";

const points = [
  "Garantia formal em peças e mão de obra",
  "Diagnóstico apresentado antes de qualquer cobrança",
  "Peças testadas antes da instalação",
  "Suporte pós-reparo se algo não ficar 100%",
];

export default function Guarantee() {
  return (
    <section id="garantia" className="bg-graphite-900 py-24 sm:py-32">
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-14 px-5 sm:px-8 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6 }}
          className="relative mx-auto flex aspect-square w-full max-w-sm items-center justify-center"
        >
          <div className="absolute inset-0 rounded-full bg-solder/10 blur-3xl" />
          <div className="glass relative flex h-56 w-56 flex-col items-center justify-center rounded-full border border-solder/30 text-center shadow-glow sm:h-64 sm:w-64">
            <ShieldCheck className="h-10 w-10 text-solder" strokeWidth={1.75} />
            <p className="mt-3 font-display text-2xl font-bold text-gradient">Garantia</p>
            <p className="font-mono text-xs uppercase tracking-widest text-bone-400">real, por escrito</p>
          </div>
        </motion.div>

        <div>
          <span className="section-label">// 05_garantia</span>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Confiança não é promessa, é documento
          </h2>
          <p className="mt-4 text-bone-400">
            Todo serviço sai da GD Tech com garantia declarada — o que foi trocado, por quanto tempo está coberto e o que fazer se precisar voltar.
          </p>

          <ul className="mt-8 space-y-4">
            {points.map((p) => (
              <li key={p} className="flex items-start gap-3">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-solder" strokeWidth={2} />
                <span className="text-sm text-bone-100 sm:text-base">{p}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
