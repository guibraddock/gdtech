"use client";

import { motion } from "framer-motion";
import { Star } from "lucide-react";

const reviews = [
  {
    name: "Marina A.",
    device: "iPhone 13 — troca de tela",
    text: "Cheguei sem esperança de recuperar as fotos e o aparelho voltou funcionando perfeito, no mesmo dia. Explicaram cada etapa antes de fazer.",
  },
  {
    name: "Rodrigo P.",
    device: "Galaxy S22 — bateria",
    text: "Achei que ia precisar trocar de celular. Trocaram só a bateria, com garantia, e ficou como novo. Preço justo e sem enrolação.",
  },
  {
    name: "Camila S.",
    device: "iPhone 11 — conector de carga",
    text: "Já tinha ido em outro lugar que não resolveu. Na GD Tech identificaram o problema real em minutos e consertaram de verdade.",
  },
];

export default function Testimonials() {
  return (
    <section id="depoimentos" className="bg-graphite-950 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-label">// 06_quem_já_passou_por_aqui</span>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Clientes que recuperaram o aparelho — e a confiança
          </h2>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-3">
          {reviews.map((r, i) => (
            <motion.figure
              key={r.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="flex flex-col rounded-2xl border border-white/5 bg-graphite-900 p-6"
            >
              <div className="flex gap-1 text-solder">
                {Array.from({ length: 5 }).map((_, idx) => (
                  <Star key={idx} className="h-4 w-4 fill-solder" strokeWidth={0} />
                ))}
              </div>
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-bone-100">
                "{r.text}"
              </blockquote>
              <figcaption className="mt-5 border-t border-white/5 pt-4">
                <p className="font-display text-sm font-semibold">{r.name}</p>
                <p className="font-mono text-xs text-bone-400">{r.device}</p>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
