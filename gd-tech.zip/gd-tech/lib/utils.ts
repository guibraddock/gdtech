import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const SITE = {
  name: "GD Tech",
  tagline: "Assistência técnica especializada em smartphones",
  phone: "21980846924",
  phoneDisplay: "(21) 98084-6924",
  whatsappBase: "https://wa.me/5521980846924",
  city: "Rio de Janeiro",
  region: "RJ",
  url: "https://gdtech.com.br",
};

export function whatsappLink(message: string) {
  return `${SITE.whatsappBase}?text=${encodeURIComponent(message)}`;
}
