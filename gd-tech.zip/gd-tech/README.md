# GD Tech — Landing Page

Landing page premium para assistência técnica de smartphones, construída com Next.js 15 (App Router), TypeScript, Tailwind CSS e Framer Motion.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000

## Antes de publicar

1. **Substitua os dados reais** em `lib/utils.ts` (objeto `SITE`): telefone/DDI, cidade e URL final do domínio.
2. **Depoimentos**: os três depoimentos em `components/testimonials.tsx` são exemplos de estrutura — troque por avaliações reais de clientes (nome + serviço + texto) antes do ar.
3. **Imagem OG**: adicione `public/og-image.jpg` (1200×630) para o preview correto no WhatsApp/redes sociais.
4. **Favicon**: adicione `public/favicon.ico`.
5. **Endereço físico**: se a GD Tech tiver loja física, adicione `streetAddress` e `postalCode` reais no `jsonLd` de `app/layout.tsx` — isso melhora SEO local (Google Meu Negócio / Maps).

## Decisões técnicas

- **Sem imagens externas no Hero**: o mockup do celular é feito 100% em CSS/HTML (não uma foto), então carrega instantâneo e não pesa no LCP.
- **next/font**: Space Grotesk, Inter e JetBrains Mono são carregadas via `next/font/google` — self-hosted automaticamente pelo Next no build, zero requisição externa em produção (o erro de rede que você vir *neste sandbox* é só porque o ambiente de teste bloqueia `fonts.googleapis.com`; em `npm run build` normal isso funciona).
- **Sem shadcn CLI**: os componentes `Button` e `AccordionItem` seguem o padrão visual/API do shadcn (cva, Tailwind, Radix-like) escritos à mão, para manter o projeto leve sem dependência extra do Radix.
- **Motion**: `whileInView` com `once: true` em vez de scroll listeners manuais — mais leve e não recalcula depois da primeira entrada em tela.
- **prefers-reduced-motion** respeitado globalmente em `globals.css`.

## Checklist de performance/SEO já implementado

- [x] Metadata completa (title template, description, keywords)
- [x] Open Graph + Twitter Cards
- [x] Schema.org `ElectronicsStore` (LocalBusiness) em JSON-LD
- [x] `robots.ts` e `sitemap.ts` dinâmicos (App Router)
- [x] Canonical via `metadataBase`
- [x] HTML semântico (`header`, `main`, `section`, `footer`, `blockquote`, `figure`)
- [x] Foco visível (`:focus-visible`) para acessibilidade de teclado
- [x] Contraste AA (texto `#F3F4F1` sobre grafite `#0B0D0F`)
- [x] `alt`/`aria-label` em elementos interativos sem texto visível

## Próximos passos recomendados para 95+ no Lighthouse

1. Rodar `npm run build && npm run start` e testar com Lighthouse/PageSpeed Insights no domínio real.
2. Adicionar imagens reais (loja, técnicos, antes/depois) via `next/image` com `sizes` definido.
3. Configurar Google Search Console + verificar o sitemap.
4. Conectar Google Analytics 4 / Meta Pixel para medir a taxa de clique no botão do WhatsApp.
